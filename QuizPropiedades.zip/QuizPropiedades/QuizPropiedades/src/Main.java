public class Main {
    public static void main(String[] args) {
        FrmPropietarios ventana = new FrmPropietarios();
        ventana.setVisible(true);
    }


}